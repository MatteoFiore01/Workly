require "test_helper"

class GigTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
