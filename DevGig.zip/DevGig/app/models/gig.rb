class Gig < ApplicationRecord

  #validation

end
